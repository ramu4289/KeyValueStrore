﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyValueStore
{
    class Program
    {
        static void Main(string[] args)
        {
            var d = new MyDictionary();
            try
            {
                Console.WriteLine(d["Water1"]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            d["Water1"] = 9;
            d["Monster2"] = 10;
            Console.WriteLine($"{(int)d["Water1"]}, {(int)d["Monster2"]}");
            d["Water1"] = 85;
            d["Monster2"] = 45;
            Console.WriteLine($"{(int)d["Water1"]}, {(int)d["Monster2"]}");
            Console.ReadLine();
        }

    }


}
