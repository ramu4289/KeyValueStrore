﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyValueStore
{
    class MyDictionary
    {

        KeyValue[] Array = new KeyValue[4]
        {
            new KeyValue("Water", 5),
            new KeyValue("Monster", 2),
            new KeyValue("Coffee", 4),
            new KeyValue("RedBull", 9),
        };

        private int Length
        {
            get
            {
                return Array.Length;
            }
        }
        public object this[string key]
        {
            get
            {
                for ( int i = 0; i < Array.Length; i++)
                {
                    if(key.ToLower() == Array[i].Key.ToLower() )
                    {
                        return Array[i].Value;
                    }
                }
                throw new KeyNotFoundException();
            }
           //make new array , copy new array, resize it
            set
            {
                KeyValue[] NewArray = new KeyValue[Array.Length + 1];

                for (int i = 0; i < Array.Length; i++)
                {
                    if (key.ToLower() == Array[i].Key.ToLower())
                    {
                        Array[i] = new KeyValue(key, value);
                    }
                   if (i == Array.Length - 1)
                    {
                        NewArray = Array;
                        Array = new KeyValue[Length + 1];
                       
                        for (int j = 0; j < NewArray.Length; j++)
                        {
                            Array[j] = NewArray[j];
                        }
                        
                      // Array[i + 1] = new KeyValue(key, value);
                        break;

                    }
                }
                Array[Array.Length - 1] = new KeyValue(key, value);


            }


        }

    }
}
